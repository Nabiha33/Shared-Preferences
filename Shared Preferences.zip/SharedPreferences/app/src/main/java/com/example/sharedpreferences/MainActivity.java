package com.example.sharedpreferences;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.example.sharedpreferences.LoginActivity;
import com.example.sharedpreferences.R;

public class MainActivity extends AppCompatActivity {

    // Keys for SharedPreferences
    private static final String SHARED_PREF_NAME = "MyAppP";
    private static final String KEY_USERNAME = "username";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView welcomeTextView = findViewById(R.id.welcomeTextView);

        // Check if the user is logged in
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        String username = sharedPreferences.getString(KEY_USERNAME, null);

        if (username == null) {
            // If no username is found, the user is not logged in, so redirect to the login page
            startActivity(new Intent(MainActivity.this, LoginActivity.class));
            finish();  // Close MainActivity so the user can't go back to it
        } else {
            // If user is logged in, display a welcome message
            welcomeTextView.setText("Welcome, " + username);
        }
    }
}